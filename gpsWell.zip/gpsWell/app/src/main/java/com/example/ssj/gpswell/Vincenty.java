package com.example.ssj.gpswell;

import android.app.Service;
import java.lang.Math.*;

/**
 * Created by ssj on 23/01/18.
 */

public class Vincenty {
    /* this is to accurately calculate the lat / long to a metric distance,
     * I need about 5m accuracy or less
     */

    private static final double a = 3963.19059; /*major radius of earth*/
    private static final double b = 6356752.314245; /*minor radius of earth*/
    private static final double f = (a - b) / a;

    public static void main(String[] args) {
        Vincenty(50.447238f, 49, (float) Math.abs(-104.611616), (float) Math.abs(-104.611616));
    }

    public static double Vincenty(float lat1, float lat2, float lgt1, float lgt2) {
        double phi1 = Math.toRadians(lat1);
        double phi2 = Math.toRadians(lat2);
        double L = Math.toRadians(lgt1) -  Math.toRadians(lgt2);
        double tanU1 = (1 - f) * Math.tan(phi1);
        double tanU2 = (1 - f) * Math.tan(phi2);
        double cosU1 = 1 / Math.sqrt((1 + tanU1 * tanU1));
        double cosU2 = 1 / Math.sqrt((1 + tanU2 * tanU2));
        double sinU1 = tanU1 * cosU1;
        double sinU2 = tanU2 * cosU2;
        double lambda = L; /* initial guess */
        int i = 100;
        double sinlambda, coslambda;
        double sinsigma, cossigma, sigma, sinalpha, cossqalpha, cos2alpham, C, nlambda;

        do {
            sinlambda = Math.sin(lambda);
            coslambda = Math.cos(lambda);
            sinsigma = Math.sqrt((cosU2 * sinlambda) * (cosU2 * sinlambda) +
                    (cosU1 * sinU2 - sinU1 * cosU2 * coslambda) *
                            (cosU1 * sinU2 - sinU1 * cosU2 * coslambda));
            cossigma = sinU1 * sinU2 + cosU1 * cosU2 * coslambda;
            sigma = Math.atan(sinsigma / cossigma);
            sinalpha = cosU1 * cosU2 * sinlambda / sinsigma;
            cossqalpha = 1 - sinalpha * sinalpha;
            cos2alpham = cossigma - 2 * sinU1 * sinU2 / cossqalpha;
            C = f / 16 * cossqalpha * (4 + f * (4 - 3 * cossqalpha));
            nlambda = lambda;
            lambda = L + (1 - C) * f * sinalpha * (sigma + C * sinsigma *
                    (cos2alpham + C * cossigma * (-1 + 2 * cos2alpham * cos2alpham)));
        } while (Math.abs(lambda - nlambda) > 1e-12 && --i > 0);

        if (i == 0) {
            System.out.println("The equation could not converge");
            return 0;
        }

        double usq = cossqalpha * (a * a - b * b) / (b * b);
        double A = 1 + usq / 16384 * (4096 + usq * (-768 + usq * (320 - 175 * usq)));
        double B = usq / 1024 * (256 + usq * (-128 + usq * (74 - 47 * usq)));
        double delsigma = B *sinsigma * (cos2alpham + B / 4 * (cossigma *
                (-1 + 2 * cos2alpham * cos2alpham) - B / 6 * cos2alpham *
                (-3 + 4 * sinsigma * sinsigma) * (-3 + 4 * cos2alpham * cos2alpham)));
        double s = b * A * (sigma - delsigma);

        System.out.println("The distance is " +  s );
        return s;
    }
}
